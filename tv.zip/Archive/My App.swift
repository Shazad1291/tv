import SwiftUI

@main
struct BottomNavBarApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}

struct MainView: View {
    var body: some View {
        TabView {
            TVView()
                .tabItem {
                    Image(systemName: "tv")
                    Text("TV")
                }
            
            InfoView()
                .tabItem {
                    Image(systemName: "info.circle")
                    Text("Info")
                }
        }
    }
}

import SwiftUI

struct InfoView: View {
    var body: some View {
        NavigationView {
            VStack {



Text("کورد تیڤی ئاپلیکەیشنێکە بۆ تەماشا کردنی چەناڵە کوردیەکان بە پەخشی راستەو خۆ دروست کراوە لە لایەن تیمی [فالکۆن] بۆ سودگەیاندن بە خەلکی                             ئاپەکەمان سودی چیە ؟                                                                               ئاپەکەمان سودی بۆ ئەو کەسانەیە کە زۆرجار لە ماڵ نین یاخود هەر لە کوردستان نین تاوەک و تەمەشای هەوال یاخود دراماکانیان بکەن لەسەر تەلەفیزیۆن لە رێی کورد تیڤی لە هەموو کات و ساتێک دەتوانی تەماشای کەناڵە کوردیەکان بکەی.")
    .font(.custom("K24KurdishBold-Bold", size: 24))
    .lineLimit(nil)
    .multilineTextAlignment(.trailing)
.padding()


                Spacer()
                
                HStack(spacing: 40) {

                    
            Button(action: {
                openURL("https://t.me/fsmain")
            }) {
                HStack {
                    Image(systemName: "paperplane.fill")
                    Text("telegram")
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(8)
            }
            .padding()
                    
                           Button(action: {
                openURL("https://tv.feye.pro")
            }) {
                HStack {
                    Image(systemName: "link")
                    Text("website")
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(8)
            }
            .padding()
                }
                

                
                // App Information Section
                VStack(spacing: 5) {
                    Text(Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String ?? "N/A")
                    
                    Text(Bundle.main.bundleIdentifier ?? "N/A")
                    
                    Text(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "N/A")
                }
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .padding(.bottom, 20)
            }
            .navigationTitle("Info")
        }
    }

    private func openURL(_ urlString: String) {
        if let url = URL(string: urlString) {
            UIApplication.shared.open(url)
        }
    }


}

struct InfoView_Previews: PreviewProvider {
    static var previews: some View {
        InfoView()
    }
}




