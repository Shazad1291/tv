import SwiftUI
import WebKit

struct ShowDetailView: View {
    let detailsUrl: String
    let name: String
    
    var body: some View {
        WebView(url: URL(string: detailsUrl)!)
            .navigationTitle(name)
    }
}

struct WebView: UIViewRepresentable {
    let url: URL

    func makeUIView(context: Context) -> WKWebView {
        WKWebView()
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        uiView.load(URLRequest(url: url))
    }
}