import SwiftUI

struct TVView: View {
    @State private var shows: [Show] = []
    
    var body: some View {
        NavigationView {
            List(shows) { show in
                NavigationLink(destination: ShowDetailView(detailsUrl: show.detailsUrl , name: show.name)) {
                    HStack {
                        LoadImage(url: URL(string: show.imageUrl)!)
                            .frame(width: 100, height: 100)
                        Text(show.name)
                            .font(.headline)
                    }
                    .padding()

                }
            }
            .navigationTitle("TV Shows")
            .onAppear {
                fetchShows()
            }
        }
    }

    func decodeBase64(_ base64String: String) -> String? {
        guard let decodedData = Data(base64Encoded: base64String) else {
            return nil
        }
        return String(data: decodedData, encoding: .utf8)
    }
    
    private func fetchShows() {
        guard let url = URL(string: decodeBase64("aHR0cHM6Ly9mZXllLnByby90di5qc29u") ?? "") else { return }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else { return }
            
            do {
                let decodedShows = try JSONDecoder().decode([Show].self, from: data)
                DispatchQueue.main.async {
                    self.shows = decodedShows
                }
            } catch {
                print("Failed to decode JSON: \(error)")
            }
        }
        
        task.resume()
    }

}

struct LoadImage: View {
    @StateObject private var loader: ImageLoader
    
    init(url: URL) {
        _loader = StateObject(wrappedValue: ImageLoader(url: url))
    }
    
    var body: some View {
        Group {
            if let image = loader.image {
                Image(uiImage: image)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            } else {
                ProgressView()
            }
        }
    }
}

class ImageLoader: ObservableObject {
    @Published var image: UIImage?
    
    private var url: URL
    
    init(url: URL) {
        self.url = url
        load()
    }


    
    private func load() {
        let task = URLSession.shared.dataTask(with: url) { data, _, _ in
            if let data = data, let image = UIImage(data: data) {
                DispatchQueue.main.async {
                    self.image = image
                }
            }
        }
        task.resume()
    }
}

struct Show: Identifiable, Decodable {
    let id = UUID()
    let name: String
    let imageUrl: String
    let detailsUrl: String
}